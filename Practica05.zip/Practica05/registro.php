<?php

require "config.php";
require APP_PATH . "views/registro.view.php";