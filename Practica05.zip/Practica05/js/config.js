// Archivo con las configuraciones de la APP que se necesitarán del lado del cliente

/**
 * Root de la app, esto para tener del lado del cliente en donde está la app
 * en relación al root del server para poder hacer peticiones AJAX.
 */
const APP_ROOT = "../Practica05/";
