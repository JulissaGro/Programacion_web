<?php

require "config.php";
require_once APP_PATH . "session.php";

require APP_PATH . "views/editar_usuario.view.php";