<?php
require_once "config.php";
require APP_PATH . "sesion_requerida.php";

$tituloPagina = "Práctica 05 - Server Side Programming";

require APP_PATH . "views/actualizar_contrasena.view.php";